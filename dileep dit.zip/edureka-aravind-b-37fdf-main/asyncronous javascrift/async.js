console.log("Task 1");

 setTimeout( ()=>{console.log("Task 2")},1000);
 setTimeout( ()=>{console.log("Task 6")},0);

console.log("Task 3");

console.log("Task 4");