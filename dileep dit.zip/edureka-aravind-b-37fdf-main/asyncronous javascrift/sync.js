console.log("Task 1");

console.log("Task 2");

console.log("Task 3");

console.log("Task 4");