<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Document</title>
  <link rel="stylesheet" href="manju.css">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p" crossorigin="anonymous"></script>

<style>
  *{
 background-color: rgb(70, 158, 235);
    letter-spacing: 2px;
    align-items: center;
 
  }

  
  .btn-1{
    margin-left: 70px;
    width: 200px;
  height: 100px;
  font-weight: bold;
  color: darkblue;
  background-color: gold;
  border-radius: 4px;
  border: none;
    text-align: center;
    box-shadow: inset 0 0 0 0 #faf5c4;
    transition: ease-out 0.2s;
    
  }
  .btn-1:hover{
    box-shadow: inset 200px 0 0 0 #f80c20;
    cursor: pointer;
    color: #000;
  }

  .btn-2{
    margin-left: 70px;
    width: 200px;
  height: 100px;
  font-weight: bold;
  color: darkblue;
  background-color: silver;
  border-radius: 4px;
  border: none;
    text-align: center;
    box-shadow: inset 0 0 0 0 #faf5c4;
    transition: ease-out 0.2s;
  }
  .btn-2:hover{
    box-shadow: inset 200px 0 0 0 #f80c20;
    cursor: pointer;
    color: #000;
  }

  .btn-3{
    margin-left: 70px;
    width: 200px;
  height: 100px;
  font-weight: bold;
  color: darkblue;
  background-color: rgb(204, 155, 90);
  border-radius: 4px;
  border: none;
    text-align: center;
    box-shadow: inset 0 0 0 0 #faf5c4;
    transition: ease-out 0.2s;
  }
  .btn-3:hover{
    box-shadow: inset 200px 0 0 0 #f80c20;
    cursor: pointer;
    color: #000;
  }
 
  .select{
    margin-top: 10px;
    outline: none;
    box-shadow: rgb(253, 250, 245);
    padding: 5px 25px;
    color: darkblue;
   background-color: rgb(247, 246, 213);
   text-align: center;
 }

.select:hover{
  box-shadow: inset 300px 0 0 0 rgb(250, 220, 245) ;
  cursor: pointer;
  color: black;

}


</style>



</head>
<body>
  

    <h1 style="color: black; font-weight: bolder;">STUDENTS MARKS LISTS</h1>

    <button class="btn-1">ARAVIND</button>
    <BUTTon class="btn-2">MANJUNATH</BUTTon>
    <BUtton class="btn-3">ASHISH</BUtton>


   <form>1. ARAVIND
<select class="select" style="   margin-left: 320px;">
  <option value="1">1-100</option>
  <option value="1">1 &percnt;</option>
  <option value="1">2 &percnt;</option>
  <option value="1">3 &percnt;</option>
  <option value="1">4 &percnt;</option>
  <option value="1">5 &percnt;</option>
  <option value="1">6 &percnt;</option>
  <option value="1">7 &percnt;</option>
  <option value="1">8 &percnt;</option>
  <option value="1">9 &percnt;</option>
  <option value="1">10&#x00025;</option>
  <option value="1">11 &percnt;</option>
  <option value="1">12 &percnt;</option>
  <option value="1">13 &percnt;</option>
  <option value="1">14 &percnt;</option>
  <option value="1">15 &percnt;</option>
  <option value="1">16 &percnt;</option>
  <option value="1">17 &percnt;</option>
  <option value="1">18 &percnt;</option>
  <option value="1">19 &percnt;</option>
  <option value="1">20&#x00025;</option>
  <option value="1">21 &percnt;</option>
  <option value="1">22 &percnt;</option>
  <option value="1">23 &percnt;</option>
  <option value="1">24 &percnt;</option>
  <option value="1">25 &percnt;</option>
  <option value="1">26 &percnt;</option>
  <option value="1">27 &percnt;</option>
  <option value="1">28 &percnt;</option>
  <option value="1">29 &percnt;</option>
  <option value="1">30&#x00025;</option>
  <option value="1">31 &percnt;</option>
  <option value="1">32 &percnt;</option>
  <option value="1">33 &percnt;</option>
  <option value="1">34 &percnt;</option>
  <option value="1">35 &percnt;</option>
  <option value="1">36 &percnt;</option>
  <option value="1">37 &percnt;</option>
  <option value="1">38 &percnt;</option>
  <option value="1">39 &percnt;</option>
  <option value="1">40&#x00025;</option>
  <option value="1">41 &percnt;</option>
  <option value="1">42 &percnt;</option>
  <option value="1">43 &percnt;</option>
  <option value="1">44 &percnt;</option>
  <option value="1">45 &percnt;</option>
  <option value="1">46 &percnt;</option>
  <option value="1">47 &percnt;</option>
  <option value="1">48 &percnt;</option>
  <option value="1">49 &percnt;</option>
  <option value="1">50&#x00025;</option>
  <option value="1">51 &percnt;</option>
  <option value="1">52 &percnt;</option>
  <option value="1">53 &percnt;</option>
  <option value="1">54 &percnt;</option>
  <option value="1">55 &percnt;</option>
  <option value="1">56 &percnt;</option>
  <option value="1">57 &percnt;</option>
  <option value="1">58 &percnt;</option>
  <option value="1">59 &percnt;</option>
  <option value="1">60&#x00025;</option>
  <option value="1">71 &percnt;</option>
  <option value="1">72 &percnt;</option>
  <option value="1">73 &percnt;</option>
  <option value="1">74 &percnt;</option>
  <option value="1">75 &percnt;</option>
  <option value="1">76 &percnt;</option>
  <option value="1">77 &percnt;</option>
  <option value="1">78 &percnt;</option>
  <option value="1">79 &percnt;</option>
  <option value="1">80&#x00025;</option>
  <option value="1">81 &percnt;</option>
  <option value="1">82 &percnt;</option>
  <option value="1">83 &percnt;</option>
  <option value="1">84 &percnt;</option>
  <option value="1">85 &percnt;</option>
  <option value="1">86 &percnt;</option>
  <option value="1">87 &percnt;</option>
  <option value="1">88 &percnt;</option>
  <option value="1">89 &percnt;</option>
  <option value="1">90&#x00025;</option>
  <option value="1">91 &percnt;</option>
  <option value="1">92 &percnt;</option>
  <option value="1">93 &percnt;</option>
  <option value="1">94 &percnt;</option>
  <option value="1">95 &percnt;</option>
  <option value="1">96 &percnt;</option>
  <option value="1">97 &percnt;</option>
  <option value="1">98 &percnt;</option>
  <option value="1">99 &percnt;</option>
  <option value="1">100&#x00025;</option>
  
</select>
 </form>  

 <form>2. MANJUNATH
  <select class="select" style="   margin-left: 288px;">
    <option value="1">1-100</option>
    <option value="1">1 &percnt;</option>
    <option value="1">2 &percnt;</option>
    <option value="1">3 &percnt;</option>
    <option value="1">4 &percnt;</option>
    <option value="1">5 &percnt;</option>
    <option value="1">6 &percnt;</option>
    <option value="1">7 &percnt;</option>
    <option value="1">8 &percnt;</option>
    <option value="1">9 &percnt;</option>
    <option value="1">10&#x00025;</option>
    <option value="1">11 &percnt;</option>
    <option value="1">12 &percnt;</option>
    <option value="1">13 &percnt;</option>
    <option value="1">14 &percnt;</option>
    <option value="1">15 &percnt;</option>
    <option value="1">16 &percnt;</option>
    <option value="1">17 &percnt;</option>
    <option value="1">18 &percnt;</option>
    <option value="1">19 &percnt;</option>
    <option value="1">20&#x00025;</option>
    <option value="1">21 &percnt;</option>
    <option value="1">22 &percnt;</option>
    <option value="1">23 &percnt;</option>
    <option value="1">24 &percnt;</option>
    <option value="1">25 &percnt;</option>
    <option value="1">26 &percnt;</option>
    <option value="1">27 &percnt;</option>
    <option value="1">28 &percnt;</option>
    <option value="1">29 &percnt;</option>
    <option value="1">30&#x00025;</option>
    <option value="1">31 &percnt;</option>
    <option value="1">32 &percnt;</option>
    <option value="1">33 &percnt;</option>
    <option value="1">34 &percnt;</option>
    <option value="1">35 &percnt;</option>
    <option value="1">36 &percnt;</option>
    <option value="1">37 &percnt;</option>
    <option value="1">38 &percnt;</option>
    <option value="1">39 &percnt;</option>
    <option value="1">40&#x00025;</option>
    <option value="1">41 &percnt;</option>
    <option value="1">42 &percnt;</option>
    <option value="1">43 &percnt;</option>
    <option value="1">44 &percnt;</option>
    <option value="1">45 &percnt;</option>
    <option value="1">46 &percnt;</option>
    <option value="1">47 &percnt;</option>
    <option value="1">48 &percnt;</option>
    <option value="1">49 &percnt;</option>
    <option value="1">50&#x00025;</option>
    <option value="1">51 &percnt;</option>
    <option value="1">52 &percnt;</option>
    <option value="1">53 &percnt;</option>
    <option value="1">54 &percnt;</option>
    <option value="1">55 &percnt;</option>
    <option value="1">56 &percnt;</option>
    <option value="1">57 &percnt;</option>
    <option value="1">58 &percnt;</option>
    <option value="1">59 &percnt;</option>
    <option value="1">60&#x00025;</option>
    <option value="1">71 &percnt;</option>
    <option value="1">72 &percnt;</option>
    <option value="1">73 &percnt;</option>
    <option value="1">74 &percnt;</option>
    <option value="1">75 &percnt;</option>
    <option value="1">76 &percnt;</option>
    <option value="1">77 &percnt;</option>
    <option value="1">78 &percnt;</option>
    <option value="1">79 &percnt;</option>
    <option value="1">80&#x00025;</option>
    <option value="1">81 &percnt;</option>
    <option value="1">82 &percnt;</option>
    <option value="1">83 &percnt;</option>
    <option value="1">84 &percnt;</option>
    <option value="1">85 &percnt;</option>
    <option value="1">86 &percnt;</option>
    <option value="1">87 &percnt;</option>
    <option value="1">88 &percnt;</option>
    <option value="1">89 &percnt;</option>
    <option value="1">90&#x00025;</option>
    <option value="1">91 &percnt;</option>
    <option value="1">92 &percnt;</option>
    <option value="1">93 &percnt;</option>
    <option value="1">94 &percnt;</option>
    <option value="1">95 &percnt;</option>
    <option value="1">96 &percnt;</option>
    <option value="1">97 &percnt;</option>
    <option value="1">98 &percnt;</option>
    <option value="1">99 &percnt;</option>
    <option value="1">100&#x00025;</option>
    
  </select>
   </form>  

   <form>3. ASHISH
    <select class="select" style="   margin-left: 332px;">
      <option value="1">1-100</option>
      <option value="1">1 &percnt;</option>
      <option value="1">2 &percnt;</option>
      <option value="1">3 &percnt;</option>
      <option value="1">4 &percnt;</option>
      <option value="1">5 &percnt;</option>
      <option value="1">6 &percnt;</option>
      <option value="1">7 &percnt;</option>
      <option value="1">8 &percnt;</option>
      <option value="1">9 &percnt;</option>
      <option value="1">10&#x00025;</option>
      <option value="1">11 &percnt;</option>
      <option value="1">12 &percnt;</option>
      <option value="1">13 &percnt;</option>
      <option value="1">14 &percnt;</option>
      <option value="1">15 &percnt;</option>
      <option value="1">16 &percnt;</option>
      <option value="1">17 &percnt;</option>
      <option value="1">18 &percnt;</option>
      <option value="1">19 &percnt;</option>
      <option value="1">20&#x00025;</option>
      <option value="1">21 &percnt;</option>
      <option value="1">22 &percnt;</option>
      <option value="1">23 &percnt;</option>
      <option value="1">24 &percnt;</option>
      <option value="1">25 &percnt;</option>
      <option value="1">26 &percnt;</option>
      <option value="1">27 &percnt;</option>
      <option value="1">28 &percnt;</option>
      <option value="1">29 &percnt;</option>
      <option value="1">30&#x00025;</option>
      <option value="1">31 &percnt;</option>
      <option value="1">32 &percnt;</option>
      <option value="1">33 &percnt;</option>
      <option value="1">34 &percnt;</option>
      <option value="1">35 &percnt;</option>
      <option value="1">36 &percnt;</option>
      <option value="1">37 &percnt;</option>
      <option value="1">38 &percnt;</option>
      <option value="1">39 &percnt;</option>
      <option value="1">40&#x00025;</option>
      <option value="1">41 &percnt;</option>
      <option value="1">42 &percnt;</option>
      <option value="1">43 &percnt;</option>
      <option value="1">44 &percnt;</option>
      <option value="1">45 &percnt;</option>
      <option value="1">46 &percnt;</option>
      <option value="1">47 &percnt;</option>
      <option value="1">48 &percnt;</option>
      <option value="1">49 &percnt;</option>
      <option value="1">50&#x00025;</option>
      <option value="1">51 &percnt;</option>
      <option value="1">52 &percnt;</option>
      <option value="1">53 &percnt;</option>
      <option value="1">54 &percnt;</option>
      <option value="1">55 &percnt;</option>
      <option value="1">56 &percnt;</option>
      <option value="1">57 &percnt;</option>
      <option value="1">58 &percnt;</option>
      <option value="1">59 &percnt;</option>
      <option value="1">60&#x00025;</option>
      <option value="1">71 &percnt;</option>
      <option value="1">72 &percnt;</option>
      <option value="1">73 &percnt;</option>
      <option value="1">74 &percnt;</option>
      <option value="1">75 &percnt;</option>
      <option value="1">76 &percnt;</option>
      <option value="1">77 &percnt;</option>
      <option value="1">78 &percnt;</option>
      <option value="1">79 &percnt;</option>
      <option value="1">80&#x00025;</option>
      <option value="1">81 &percnt;</option>
      <option value="1">82 &percnt;</option>
      <option value="1">83 &percnt;</option>
      <option value="1">84 &percnt;</option>
      <option value="1">85 &percnt;</option>
      <option value="1">86 &percnt;</option>
      <option value="1">87 &percnt;</option>
      <option value="1">88 &percnt;</option>
      <option value="1">89 &percnt;</option>
      <option value="1">90&#x00025;</option>
      <option value="1">91 &percnt;</option>
      <option value="1">92 &percnt;</option>
      <option value="1">93 &percnt;</option>
      <option value="1">94 &percnt;</option>
      <option value="1">95 &percnt;</option>
      <option value="1">96 &percnt;</option>
      <option value="1">97 &percnt;</option>
      <option value="1">98 &percnt;</option>
      <option value="1">99 &percnt;</option>
      <option value="1">100&#x00025;</option>
      
    </select>
     </form>  

     <form>4. ASHWINI
      <select class="select" style="   margin-left: 321px;">
        <option value="1">1-100</option>
        <option value="1">1 &percnt;</option>
        <option value="1">2 &percnt;</option>
        <option value="1">3 &percnt;</option>
        <option value="1">4 &percnt;</option>
        <option value="1">5 &percnt;</option>
        <option value="1">6 &percnt;</option>
        <option value="1">7 &percnt;</option>
        <option value="1">8 &percnt;</option>
        <option value="1">9 &percnt;</option>
        <option value="1">10&#x00025;</option>
        <option value="1">11 &percnt;</option>
        <option value="1">12 &percnt;</option>
        <option value="1">13 &percnt;</option>
        <option value="1">14 &percnt;</option>
        <option value="1">15 &percnt;</option>
        <option value="1">16 &percnt;</option>
        <option value="1">17 &percnt;</option>
        <option value="1">18 &percnt;</option>
        <option value="1">19 &percnt;</option>
        <option value="1">20&#x00025;</option>
        <option value="1">21 &percnt;</option>
        <option value="1">22 &percnt;</option>
        <option value="1">23 &percnt;</option>
        <option value="1">24 &percnt;</option>
        <option value="1">25 &percnt;</option>
        <option value="1">26 &percnt;</option>
        <option value="1">27 &percnt;</option>
        <option value="1">28 &percnt;</option>
        <option value="1">29 &percnt;</option>
        <option value="1">30&#x00025;</option>
        <option value="1">31 &percnt;</option>
        <option value="1">32 &percnt;</option>
        <option value="1">33 &percnt;</option>
        <option value="1">34 &percnt;</option>
        <option value="1">35 &percnt;</option>
        <option value="1">36 &percnt;</option>
        <option value="1">37 &percnt;</option>
        <option value="1">38 &percnt;</option>
        <option value="1">39 &percnt;</option>
        <option value="1">40&#x00025;</option>
        <option value="1">41 &percnt;</option>
        <option value="1">42 &percnt;</option>
        <option value="1">43 &percnt;</option>
        <option value="1">44 &percnt;</option>
        <option value="1">45 &percnt;</option>
        <option value="1">46 &percnt;</option>
        <option value="1">47 &percnt;</option>
        <option value="1">48 &percnt;</option>
        <option value="1">49 &percnt;</option>
        <option value="1">50&#x00025;</option>
        <option value="1">51 &percnt;</option>
        <option value="1">52 &percnt;</option>
        <option value="1">53 &percnt;</option>
        <option value="1">54 &percnt;</option>
        <option value="1">55 &percnt;</option>
        <option value="1">56 &percnt;</option>
        <option value="1">57 &percnt;</option>
        <option value="1">58 &percnt;</option>
        <option value="1">59 &percnt;</option>
        <option value="1">60&#x00025;</option>
        <option value="1">71 &percnt;</option>
        <option value="1">72 &percnt;</option>
        <option value="1">73 &percnt;</option>
        <option value="1">74 &percnt;</option>
        <option value="1">75 &percnt;</option>
        <option value="1">76 &percnt;</option>
        <option value="1">77 &percnt;</option>
        <option value="1">78 &percnt;</option>
        <option value="1">79 &percnt;</option>
        <option value="1">80&#x00025;</option>
        <option value="1">81 &percnt;</option>
        <option value="1">82 &percnt;</option>
        <option value="1">83 &percnt;</option>
        <option value="1">84 &percnt;</option>
        <option value="1">85 &percnt;</option>
        <option value="1">86 &percnt;</option>
        <option value="1">87 &percnt;</option>
        <option value="1">88 &percnt;</option>
        <option value="1">89 &percnt;</option>
        <option value="1">90&#x00025;</option>
        <option value="1">91 &percnt;</option>
        <option value="1">92 &percnt;</option>
        <option value="1">93 &percnt;</option>
        <option value="1">94 &percnt;</option>
        <option value="1">95 &percnt;</option>
        <option value="1">96 &percnt;</option>
        <option value="1">97 &percnt;</option>
        <option value="1">98 &percnt;</option>
        <option value="1">99 &percnt;</option>
        <option value="1">100&#x00025;</option>
        
      </select>
       </form>  

       <form>5. SHARADA
        <select class="select" style="   margin-left: 315px;">
          <option value="1">1-100</option>
          <option value="1">1 &percnt;</option>
          <option value="1">2 &percnt;</option>
          <option value="1">3 &percnt;</option>
          <option value="1">4 &percnt;</option>
          <option value="1">5 &percnt;</option>
          <option value="1">6 &percnt;</option>
          <option value="1">7 &percnt;</option>
          <option value="1">8 &percnt;</option>
          <option value="1">9 &percnt;</option>
          <option value="1">10&#x00025;</option>
          <option value="1">11 &percnt;</option>
          <option value="1">12 &percnt;</option>
          <option value="1">13 &percnt;</option>
          <option value="1">14 &percnt;</option>
          <option value="1">15 &percnt;</option>
          <option value="1">16 &percnt;</option>
          <option value="1">17 &percnt;</option>
          <option value="1">18 &percnt;</option>
          <option value="1">19 &percnt;</option>
          <option value="1">20&#x00025;</option>
          <option value="1">21 &percnt;</option>
          <option value="1">22 &percnt;</option>
          <option value="1">23 &percnt;</option>
          <option value="1">24 &percnt;</option>
          <option value="1">25 &percnt;</option>
          <option value="1">26 &percnt;</option>
          <option value="1">27 &percnt;</option>
          <option value="1">28 &percnt;</option>
          <option value="1">29 &percnt;</option>
          <option value="1">30&#x00025;</option>
          <option value="1">31 &percnt;</option>
          <option value="1">32 &percnt;</option>
          <option value="1">33 &percnt;</option>
          <option value="1">34 &percnt;</option>
          <option value="1">35 &percnt;</option>
          <option value="1">36 &percnt;</option>
          <option value="1">37 &percnt;</option>
          <option value="1">38 &percnt;</option>
          <option value="1">39 &percnt;</option>
          <option value="1">40&#x00025;</option>
          <option value="1">41 &percnt;</option>
          <option value="1">42 &percnt;</option>
          <option value="1">43 &percnt;</option>
          <option value="1">44 &percnt;</option>
          <option value="1">45 &percnt;</option>
          <option value="1">46 &percnt;</option>
          <option value="1">47 &percnt;</option>
          <option value="1">48 &percnt;</option>
          <option value="1">49 &percnt;</option>
          <option value="1">50&#x00025;</option>
          <option value="1">51 &percnt;</option>
          <option value="1">52 &percnt;</option>
          <option value="1">53 &percnt;</option>
          <option value="1">54 &percnt;</option>
          <option value="1">55 &percnt;</option>
          <option value="1">56 &percnt;</option>
          <option value="1">57 &percnt;</option>
          <option value="1">58 &percnt;</option>
          <option value="1">59 &percnt;</option>
          <option value="1">60&#x00025;</option>
          <option value="1">71 &percnt;</option>
          <option value="1">72 &percnt;</option>
          <option value="1">73 &percnt;</option>
          <option value="1">74 &percnt;</option>
          <option value="1">75 &percnt;</option>
          <option value="1">76 &percnt;</option>
          <option value="1">77 &percnt;</option>
          <option value="1">78 &percnt;</option>
          <option value="1">79 &percnt;</option>
          <option value="1">80&#x00025;</option>
          <option value="1">81 &percnt;</option>
          <option value="1">82 &percnt;</option>
          <option value="1">83 &percnt;</option>
          <option value="1">84 &percnt;</option>
          <option value="1">85 &percnt;</option>
          <option value="1">86 &percnt;</option>
          <option value="1">87 &percnt;</option>
          <option value="1">88 &percnt;</option>
          <option value="1">89 &percnt;</option>
          <option value="1">90&#x00025;</option>
          <option value="1">91 &percnt;</option>
          <option value="1">92 &percnt;</option>
          <option value="1">93 &percnt;</option>
          <option value="1">94 &percnt;</option>
          <option value="1">95 &percnt;</option>
          <option value="1">96 &percnt;</option>
          <option value="1">97 &percnt;</option>
          <option value="1">98 &percnt;</option>
          <option value="1">99 &percnt;</option>
          <option value="1">100&#x00025;</option>
          
        </select>
         </form>  

         <form>6. VINAYAK
          <select class="select" style="   margin-left: 324px;">
            <option value="1">1-100</option>
            <option value="1">1 &percnt;</option>
            <option value="1">2 &percnt;</option>
            <option value="1">3 &percnt;</option>
            <option value="1">4 &percnt;</option>
            <option value="1">5 &percnt;</option>
            <option value="1">6 &percnt;</option>
            <option value="1">7 &percnt;</option>
            <option value="1">8 &percnt;</option>
            <option value="1">9 &percnt;</option>
            <option value="1">10&#x00025;</option>
            <option value="1">11 &percnt;</option>
            <option value="1">12 &percnt;</option>
            <option value="1">13 &percnt;</option>
            <option value="1">14 &percnt;</option>
            <option value="1">15 &percnt;</option>
            <option value="1">16 &percnt;</option>
            <option value="1">17 &percnt;</option>
            <option value="1">18 &percnt;</option>
            <option value="1">19 &percnt;</option>
            <option value="1">20&#x00025;</option>
            <option value="1">21 &percnt;</option>
            <option value="1">22 &percnt;</option>
            <option value="1">23 &percnt;</option>
            <option value="1">24 &percnt;</option>
            <option value="1">25 &percnt;</option>
            <option value="1">26 &percnt;</option>
            <option value="1">27 &percnt;</option>
            <option value="1">28 &percnt;</option>
            <option value="1">29 &percnt;</option>
            <option value="1">30&#x00025;</option>
            <option value="1">31 &percnt;</option>
            <option value="1">32 &percnt;</option>
            <option value="1">33 &percnt;</option>
            <option value="1">34 &percnt;</option>
            <option value="1">35 &percnt;</option>
            <option value="1">36 &percnt;</option>
            <option value="1">37 &percnt;</option>
            <option value="1">38 &percnt;</option>
            <option value="1">39 &percnt;</option>
            <option value="1">40&#x00025;</option>
            <option value="1">41 &percnt;</option>
            <option value="1">42 &percnt;</option>
            <option value="1">43 &percnt;</option>
            <option value="1">44 &percnt;</option>
            <option value="1">45 &percnt;</option>
            <option value="1">46 &percnt;</option>
            <option value="1">47 &percnt;</option>
            <option value="1">48 &percnt;</option>
            <option value="1">49 &percnt;</option>
            <option value="1">50&#x00025;</option>
            <option value="1">51 &percnt;</option>
            <option value="1">52 &percnt;</option>
            <option value="1">53 &percnt;</option>
            <option value="1">54 &percnt;</option>
            <option value="1">55 &percnt;</option>
            <option value="1">56 &percnt;</option>
            <option value="1">57 &percnt;</option>
            <option value="1">58 &percnt;</option>
            <option value="1">59 &percnt;</option>
            <option value="1">60&#x00025;</option>
            <option value="1">71 &percnt;</option>
            <option value="1">72 &percnt;</option>
            <option value="1">73 &percnt;</option>
            <option value="1">74 &percnt;</option>
            <option value="1">75 &percnt;</option>
            <option value="1">76 &percnt;</option>
            <option value="1">77 &percnt;</option>
            <option value="1">78 &percnt;</option>
            <option value="1">79 &percnt;</option>
            <option value="1">80&#x00025;</option>
            <option value="1">81 &percnt;</option>
            <option value="1">82 &percnt;</option>
            <option value="1">83 &percnt;</option>
            <option value="1">84 &percnt;</option>
            <option value="1">85 &percnt;</option>
            <option value="1">86 &percnt;</option>
            <option value="1">87 &percnt;</option>
            <option value="1">88 &percnt;</option>
            <option value="1">89 &percnt;</option>
            <option value="1">90&#x00025;</option>
            <option value="1">91 &percnt;</option>
            <option value="1">92 &percnt;</option>
            <option value="1">93 &percnt;</option>
            <option value="1">94 &percnt;</option>
            <option value="1">95 &percnt;</option>
            <option value="1">96 &percnt;</option>
            <option value="1">97 &percnt;</option>
            <option value="1">98 &percnt;</option>
            <option value="1">99 &percnt;</option>
            <option value="1">100&#x00025;</option>
            
          </select>
           </form>  

           <form>7. KARTHIK
            <select class="select" style="   margin-left: 324px;">
              <option value="1">1-100</option>
              <option value="1">1 &percnt;</option>
              <option value="1">2 &percnt;</option>
              <option value="1">3 &percnt;</option>
              <option value="1">4 &percnt;</option>
              <option value="1">5 &percnt;</option>
              <option value="1">6 &percnt;</option>
              <option value="1">7 &percnt;</option>
              <option value="1">8 &percnt;</option>
              <option value="1">9 &percnt;</option>
              <option value="1">10&#x00025;</option>
              <option value="1">11 &percnt;</option>
              <option value="1">12 &percnt;</option>
              <option value="1">13 &percnt;</option>
              <option value="1">14 &percnt;</option>
              <option value="1">15 &percnt;</option>
              <option value="1">16 &percnt;</option>
              <option value="1">17 &percnt;</option>
              <option value="1">18 &percnt;</option>
              <option value="1">19 &percnt;</option>
              <option value="1">20&#x00025;</option>
              <option value="1">21 &percnt;</option>
              <option value="1">22 &percnt;</option>
              <option value="1">23 &percnt;</option>
              <option value="1">24 &percnt;</option>
              <option value="1">25 &percnt;</option>
              <option value="1">26 &percnt;</option>
              <option value="1">27 &percnt;</option>
              <option value="1">28 &percnt;</option>
              <option value="1">29 &percnt;</option>
              <option value="1">30&#x00025;</option>
              <option value="1">31 &percnt;</option>
              <option value="1">32 &percnt;</option>
              <option value="1">33 &percnt;</option>
              <option value="1">34 &percnt;</option>
              <option value="1">35 &percnt;</option>
              <option value="1">36 &percnt;</option>
              <option value="1">37 &percnt;</option>
              <option value="1">38 &percnt;</option>
              <option value="1">39 &percnt;</option>
              <option value="1">40&#x00025;</option>
              <option value="1">41 &percnt;</option>
              <option value="1">42 &percnt;</option>
              <option value="1">43 &percnt;</option>
              <option value="1">44 &percnt;</option>
              <option value="1">45 &percnt;</option>
              <option value="1">46 &percnt;</option>
              <option value="1">47 &percnt;</option>
              <option value="1">48 &percnt;</option>
              <option value="1">49 &percnt;</option>
              <option value="1">50&#x00025;</option>
              <option value="1">51 &percnt;</option>
              <option value="1">52 &percnt;</option>
              <option value="1">53 &percnt;</option>
              <option value="1">54 &percnt;</option>
              <option value="1">55 &percnt;</option>
              <option value="1">56 &percnt;</option>
              <option value="1">57 &percnt;</option>
              <option value="1">58 &percnt;</option>
              <option value="1">59 &percnt;</option>
              <option value="1">60&#x00025;</option>
              <option value="1">71 &percnt;</option>
              <option value="1">72 &percnt;</option>
              <option value="1">73 &percnt;</option>
              <option value="1">74 &percnt;</option>
              <option value="1">75 &percnt;</option>
              <option value="1">76 &percnt;</option>
              <option value="1">77 &percnt;</option>
              <option value="1">78 &percnt;</option>
              <option value="1">79 &percnt;</option>
              <option value="1">80&#x00025;</option>
              <option value="1">81 &percnt;</option>
              <option value="1">82 &percnt;</option>
              <option value="1">83 &percnt;</option>
              <option value="1">84 &percnt;</option>
              <option value="1">85 &percnt;</option>
              <option value="1">86 &percnt;</option>
              <option value="1">87 &percnt;</option>
              <option value="1">88 &percnt;</option>
              <option value="1">89 &percnt;</option>
              <option value="1">90&#x00025;</option>
              <option value="1">91 &percnt;</option>
              <option value="1">92 &percnt;</option>
              <option value="1">93 &percnt;</option>
              <option value="1">94 &percnt;</option>
              <option value="1">95 &percnt;</option>
              <option value="1">96 &percnt;</option>
              <option value="1">97 &percnt;</option>
              <option value="1">98 &percnt;</option>
              <option value="1">99 &percnt;</option>
              <option value="1">100&#x00025;</option>
              
            </select>
             </form>  

               <form>8. AVINASH
                <select class="select" style="   margin-left: 321px;">
                  <option value="1">1-100</option>
                  <option value="1">1 &percnt;</option>
                  <option value="1">2 &percnt;</option>
                  <option value="1">3 &percnt;</option>
                  <option value="1">4 &percnt;</option>
                  <option value="1">5 &percnt;</option>
                  <option value="1">6 &percnt;</option>
                  <option value="1">7 &percnt;</option>
                  <option value="1">8 &percnt;</option>
                  <option value="1">9 &percnt;</option>
                  <option value="1">10&#x00025;</option>
                  <option value="1">11 &percnt;</option>
                  <option value="1">12 &percnt;</option>
                  <option value="1">13 &percnt;</option>
                  <option value="1">14 &percnt;</option>
                  <option value="1">15 &percnt;</option>
                  <option value="1">16 &percnt;</option>
                  <option value="1">17 &percnt;</option>
                  <option value="1">18 &percnt;</option>
                  <option value="1">19 &percnt;</option>
                  <option value="1">20&#x00025;</option>
                  <option value="1">21 &percnt;</option>
                  <option value="1">22 &percnt;</option>
                  <option value="1">23 &percnt;</option>
                  <option value="1">24 &percnt;</option>
                  <option value="1">25 &percnt;</option>
                  <option value="1">26 &percnt;</option>
                  <option value="1">27 &percnt;</option>
                  <option value="1">28 &percnt;</option>
                  <option value="1">29 &percnt;</option>
                  <option value="1">30&#x00025;</option>
                  <option value="1">31 &percnt;</option>
                  <option value="1">32 &percnt;</option>
                  <option value="1">33 &percnt;</option>
                  <option value="1">34 &percnt;</option>
                  <option value="1">35 &percnt;</option>
                  <option value="1">36 &percnt;</option>
                  <option value="1">37 &percnt;</option>
                  <option value="1">38 &percnt;</option>
                  <option value="1">39 &percnt;</option>
                  <option value="1">40&#x00025;</option>
                  <option value="1">41 &percnt;</option>
                  <option value="1">42 &percnt;</option>
                  <option value="1">43 &percnt;</option>
                  <option value="1">44 &percnt;</option>
                  <option value="1">45 &percnt;</option>
                  <option value="1">46 &percnt;</option>
                  <option value="1">47 &percnt;</option>
                  <option value="1">48 &percnt;</option>
                  <option value="1">49 &percnt;</option>
                  <option value="1">50&#x00025;</option>
                  <option value="1">51 &percnt;</option>
                  <option value="1">52 &percnt;</option>
                  <option value="1">53 &percnt;</option>
                  <option value="1">54 &percnt;</option>
                  <option value="1">55 &percnt;</option>
                  <option value="1">56 &percnt;</option>
                  <option value="1">57 &percnt;</option>
                  <option value="1">58 &percnt;</option>
                  <option value="1">59 &percnt;</option>
                  <option value="1">60&#x00025;</option>
                  <option value="1">71 &percnt;</option>
                  <option value="1">72 &percnt;</option>
                  <option value="1">73 &percnt;</option>
                  <option value="1">74 &percnt;</option>
                  <option value="1">75 &percnt;</option>
                  <option value="1">76 &percnt;</option>
                  <option value="1">77 &percnt;</option>
                  <option value="1">78 &percnt;</option>
                  <option value="1">79 &percnt;</option>
                  <option value="1">80&#x00025;</option>
                  <option value="1">81 &percnt;</option>
                  <option value="1">82 &percnt;</option>
                  <option value="1">83 &percnt;</option>
                  <option value="1">84 &percnt;</option>
                  <option value="1">85 &percnt;</option>
                  <option value="1">86 &percnt;</option>
                  <option value="1">87 &percnt;</option>
                  <option value="1">88 &percnt;</option>
                  <option value="1">89 &percnt;</option>
                  <option value="1">90&#x00025;</option>
                  <option value="1">91 &percnt;</option>
                  <option value="1">92 &percnt;</option>
                  <option value="1">93 &percnt;</option>
                  <option value="1">94 &percnt;</option>
                  <option value="1">95 &percnt;</option>
                  <option value="1">96 &percnt;</option>
                  <option value="1">97 &percnt;</option>
                  <option value="1">98 &percnt;</option>
                  <option value="1">99 &percnt;</option>
                  <option value="1">100&#x00025;</option>
                  
                </select>
                 </form>  

                 <form>9. VEERESH
                  <select class="select" style="   margin-left: 322px;">
                    <option value="1">1-100</option>
                    <option value="1">1 &percnt;</option>
                    <option value="1">2 &percnt;</option>
                    <option value="1">3 &percnt;</option>
                    <option value="1">4 &percnt;</option>
                    <option value="1">5 &percnt;</option>
                    <option value="1">6 &percnt;</option>
                    <option value="1">7 &percnt;</option>
                    <option value="1">8 &percnt;</option>
                    <option value="1">9 &percnt;</option>
                    <option value="1">10&#x00025;</option>
                    <option value="1">11 &percnt;</option>
                    <option value="1">12 &percnt;</option>
                    <option value="1">13 &percnt;</option>
                    <option value="1">14 &percnt;</option>
                    <option value="1">15 &percnt;</option>
                    <option value="1">16 &percnt;</option>
                    <option value="1">17 &percnt;</option>
                    <option value="1">18 &percnt;</option>
                    <option value="1">19 &percnt;</option>
                    <option value="1">20&#x00025;</option>
                    <option value="1">21 &percnt;</option>
                    <option value="1">22 &percnt;</option>
                    <option value="1">23 &percnt;</option>
                    <option value="1">24 &percnt;</option>
                    <option value="1">25 &percnt;</option>
                    <option value="1">26 &percnt;</option>
                    <option value="1">27 &percnt;</option>
                    <option value="1">28 &percnt;</option>
                    <option value="1">29 &percnt;</option>
                    <option value="1">30&#x00025;</option>
                    <option value="1">31 &percnt;</option>
                    <option value="1">32 &percnt;</option>
                    <option value="1">33 &percnt;</option>
                    <option value="1">34 &percnt;</option>
                    <option value="1">35 &percnt;</option>
                    <option value="1">36 &percnt;</option>
                    <option value="1">37 &percnt;</option>
                    <option value="1">38 &percnt;</option>
                    <option value="1">39 &percnt;</option>
                    <option value="1">40&#x00025;</option>
                    <option value="1">41 &percnt;</option>
                    <option value="1">42 &percnt;</option>
                    <option value="1">43 &percnt;</option>
                    <option value="1">44 &percnt;</option>
                    <option value="1">45 &percnt;</option>
                    <option value="1">46 &percnt;</option>
                    <option value="1">47 &percnt;</option>
                    <option value="1">48 &percnt;</option>
                    <option value="1">49 &percnt;</option>
                    <option value="1">50&#x00025;</option>
                    <option value="1">51 &percnt;</option>
                    <option value="1">52 &percnt;</option>
                    <option value="1">53 &percnt;</option>
                    <option value="1">54 &percnt;</option>
                    <option value="1">55 &percnt;</option>
                    <option value="1">56 &percnt;</option>
                    <option value="1">57 &percnt;</option>
                    <option value="1">58 &percnt;</option>
                    <option value="1">59 &percnt;</option>
                    <option value="1">60&#x00025;</option>
                    <option value="1">71 &percnt;</option>
                    <option value="1">72 &percnt;</option>
                    <option value="1">73 &percnt;</option>
                    <option value="1">74 &percnt;</option>
                    <option value="1">75 &percnt;</option>
                    <option value="1">76 &percnt;</option>
                    <option value="1">77 &percnt;</option>
                    <option value="1">78 &percnt;</option>
                    <option value="1">79 &percnt;</option>
                    <option value="1">80&#x00025;</option>
                    <option value="1">81 &percnt;</option>
                    <option value="1">82 &percnt;</option>
                    <option value="1">83 &percnt;</option>
                    <option value="1">84 &percnt;</option>
                    <option value="1">85 &percnt;</option>
                    <option value="1">86 &percnt;</option>
                    <option value="1">87 &percnt;</option>
                    <option value="1">88 &percnt;</option>
                    <option value="1">89 &percnt;</option>
                    <option value="1">90&#x00025;</option>
                    <option value="1">91 &percnt;</option>
                    <option value="1">92 &percnt;</option>
                    <option value="1">93 &percnt;</option>
                    <option value="1">94 &percnt;</option>
                    <option value="1">95 &percnt;</option>
                    <option value="1">96 &percnt;</option>
                    <option value="1">97 &percnt;</option>
                    <option value="1">98 &percnt;</option>
                    <option value="1">99 &percnt;</option>
                    <option value="1">100&#x00025;</option>
                    
                  </select>
                   </form>  

                   <form>10. SANTOSH
                    <select class="select" style="   margin-left: 307px;">
                      <option value="1">1-100</option>
                      <option value="1">1 &percnt;</option>
                      <option value="1">2 &percnt;</option>
                      <option value="1">3 &percnt;</option>
                      <option value="1">4 &percnt;</option>
                      <option value="1">5 &percnt;</option>
                      <option value="1">6 &percnt;</option>
                      <option value="1">7 &percnt;</option>
                      <option value="1">8 &percnt;</option>
                      <option value="1">9 &percnt;</option>
                      <option value="1">10&#x00025;</option>
                      <option value="1">11 &percnt;</option>
                      <option value="1">12 &percnt;</option>
                      <option value="1">13 &percnt;</option>
                      <option value="1">14 &percnt;</option>
                      <option value="1">15 &percnt;</option>
                      <option value="1">16 &percnt;</option>
                      <option value="1">17 &percnt;</option>
                      <option value="1">18 &percnt;</option>
                      <option value="1">19 &percnt;</option>
                      <option value="1">20&#x00025;</option>
                      <option value="1">21 &percnt;</option>
                      <option value="1">22 &percnt;</option>
                      <option value="1">23 &percnt;</option>
                      <option value="1">24 &percnt;</option>
                      <option value="1">25 &percnt;</option>
                      <option value="1">26 &percnt;</option>
                      <option value="1">27 &percnt;</option>
                      <option value="1">28 &percnt;</option>
                      <option value="1">29 &percnt;</option>
                      <option value="1">30&#x00025;</option>
                      <option value="1">31 &percnt;</option>
                      <option value="1">32 &percnt;</option>
                      <option value="1">33 &percnt;</option>
                      <option value="1">34 &percnt;</option>
                      <option value="1">35 &percnt;</option>
                      <option value="1">36 &percnt;</option>
                      <option value="1">37 &percnt;</option>
                      <option value="1">38 &percnt;</option>
                      <option value="1">39 &percnt;</option>
                      <option value="1">40&#x00025;</option>
                      <option value="1">41 &percnt;</option>
                      <option value="1">42 &percnt;</option>
                      <option value="1">43 &percnt;</option>
                      <option value="1">44 &percnt;</option>
                      <option value="1">45 &percnt;</option>
                      <option value="1">46 &percnt;</option>
                      <option value="1">47 &percnt;</option>
                      <option value="1">48 &percnt;</option>
                      <option value="1">49 &percnt;</option>
                      <option value="1">50&#x00025;</option>
                      <option value="1">51 &percnt;</option>
                      <option value="1">52 &percnt;</option>
                      <option value="1">53 &percnt;</option>
                      <option value="1">54 &percnt;</option>
                      <option value="1">55 &percnt;</option>
                      <option value="1">56 &percnt;</option>
                      <option value="1">57 &percnt;</option>
                      <option value="1">58 &percnt;</option>
                      <option value="1">59 &percnt;</option>
                      <option value="1">60&#x00025;</option>
                      <option value="1">71 &percnt;</option>
                      <option value="1">72 &percnt;</option>
                      <option value="1">73 &percnt;</option>
                      <option value="1">74 &percnt;</option>
                      <option value="1">75 &percnt;</option>
                      <option value="1">76 &percnt;</option>
                      <option value="1">77 &percnt;</option>
                      <option value="1">78 &percnt;</option>
                      <option value="1">79 &percnt;</option>
                      <option value="1">80&#x00025;</option>
                      <option value="1">81 &percnt;</option>
                      <option value="1">82 &percnt;</option>
                      <option value="1">83 &percnt;</option>
                      <option value="1">84 &percnt;</option>
                      <option value="1">85 &percnt;</option>
                      <option value="1">86 &percnt;</option>
                      <option value="1">87 &percnt;</option>
                      <option value="1">88 &percnt;</option>
                      <option value="1">89 &percnt;</option>
                      <option value="1">90&#x00025;</option>
                      <option value="1">91 &percnt;</option>
                      <option value="1">92 &percnt;</option>
                      <option value="1">93 &percnt;</option>
                      <option value="1">94 &percnt;</option>
                      <option value="1">95 &percnt;</option>
                      <option value="1">96 &percnt;</option>
                      <option value="1">97 &percnt;</option>
                      <option value="1">98 &percnt;</option>
                      <option value="1">99 &percnt;</option>
                      <option value="1">100&#x00025;</option>
                      
                    </select>
                     </form>  
          </div>
</body>
</html>