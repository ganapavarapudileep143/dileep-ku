function isEven(val){
    if (val%2==0){
        return true;
    }
    else{
        return false;
    }
}
console.log(isEven(100));
console.log(isEven(101));



function isEven(val){
 const result = val%2==0 ? true : false;
 return result;
}
console.log(isEven(100));
console.log(isEven(101));