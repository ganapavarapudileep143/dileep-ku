
const currentDate = new Date();
console.log(currentDate);