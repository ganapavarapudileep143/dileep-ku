
var  num=10;
var num2 = 20;

let myname="aravind";
console.log(myname);
console.log(num);
console.log(num2);

let marks=100;
marks=200;
console.log(marks);